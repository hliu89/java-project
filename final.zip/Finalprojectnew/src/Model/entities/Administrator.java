package Model.entities;

public class Administrator extends User{

	
}
